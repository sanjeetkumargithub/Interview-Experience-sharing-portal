<?php 
@session_start();

include('include/db.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Interview Experience Sharing Portal!</title>

<style type="text/css">

</style>
</head>



<body >
<div style="position:absolute;">
<div>
<center>
		<form method="get" action="search_student.php?search" enctype="meltipart/form-data"  >
		<table style="height:auto; width:80%;">
		<tr>
		<th >
				
		<input type="text" name="search_q"  placeholder=" Search Student Name" style="width:50%; height:40px;		font-size:28px;		text-align:left;" required/>
		
<button  name="search"   >   <img src="image/searching.jfif"  style="width:40px; height:40px; "/> </button>
		

	</th>
		</tr>
		</table>
		</form>
       
        </center>
		</div>


<form method="post" action="">
<table align="center" style="background-color:#FFF; border:solid;  margin-left:-60px;" height="auto"width="182%">
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px;'> Views All  Interview Experience Sharing Students</h2></tr>
<tr> 
<th> Stu No</th>
<th> Image</th>
<th> NAME</th>
<th> Email</th>

<th> Mb.No</th>
<th> Program</th>

</tr>
<?php

$sel_stu="select * from student";
$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$s_name=$row['s_name'];
	$s_gmail=$row['s_gmail'];
	$s_mb=$row['s_mb'];
	$s_image=$row['s_image'];
	$s_course=$row['s_pro'];
?>


<tr style="color:#666; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><a href="particular_page.php?particular=<?php  echo $s_id;?> "  style="text-decoration:none;" > <img src='image/<?php echo $s_image; ?>' 
					'height='15%' 	width='20%'style="border-radius:50%;"alt="Avatar" /></a> </td>
<td><?php echo $s_name;?></td>
<td><?php echo $s_gmail;?></td>
<td><?php echo $s_mb;?></td>


<td><?php echo $s_course;?></td>

</tr>
	
<?php }
?>

</table>
</form>
</div>
</body>
</html>

<?php  ?>