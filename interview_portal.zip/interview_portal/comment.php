<?php
session_start();

  include("include/db.php");

if(isset($_POST['submit'])){
	$comment=$_POST['comment'];
	$s_id=$_SESSION['to_id'];
	$from_id=$_SESSION['s_gmail'];
	$date=date("d-m-y");
	$q=0;
	$me_in="insert into cumment (s_id,comment_gmail,message,date,ques_id)
	values('$s_id','$from_id','$comment','$date','$q')";
	$ffff=mysqli_query($con,$me_in);
	if($ffff){

		echo "<script>window.open('view_student.php','_self') </script>";}

else

{
		echo "<script>window.open('view_student.php?comment=$s_id','_self') </script>";}
} 

if(isset($_POST['submit_com'])){
	$comment=$_POST['comment'];
	$ques_id=$_SESSION['ques_id'];
	$from_id=$_SESSION['s_gmail'];
	$date=date("d-m-y");
	$sel_stu="select * from s_exp_q where ques_id='$ques_id'";

$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	
	
	
	
	$me_in="insert into cumment (s_id,comment_gmail,message,date,ques_id)
	values('$s_id','$from_id','$comment','$date',$ques_id)";
	$ffff=mysqli_query($con,$me_in);
	if($ffff){
		
		echo "<script>window.open('index.php?exp','_self') </script>";}

else

{
		echo "<script>window.open('single_com.php','_self') </script>";}
} 



?>