<?php

  include("include/db.php");

if(isset($_POST['submit'])){
	$s_mb=$_POST['s_mb'];
	$s_name=$_POST['s_name'];
	$s_email=$_POST['s_email'];
	$s_subject=$_POST['s_subject'];
	$s_message=$_POST['s_message'];
	
	$me_in="insert into contact (name,email,mb,sub,message)
	values('$s_name','$s_email','$s_mb','$s_subject','$s_message')";
	$ffff=mysqli_query($con,$me_in);
	if($ffff){
		echo "<script>alert('Your Messages is Successfully submit Thanks!') </script>";
		
	}
} 
?>

<div style="width:100%;height:auto;  text-align:center;  float:left; background:#CCCCCC; position:absolute;">
	
					<div style=" border:3px solid #CC0000; width:100%;height:auto; border-radius:15px 15px 0px 0px;  "> 
		
								<div style="background:#CC0000; height:auto; width:auto;">
								<h2 style=" color : white;">	  					STUDENT CONTACT US</h2> </div>	
								
								
								<div >
									<tr> <th><b >Site:</b></th> <td><span >Interview Experience Sharing Portal </span></td></tr>&nbsp;&nbsp;
							
									<tr> <th><b margin>City</b></th> <td><span >MNNIT Allahabad</span> </td></tr>&nbsp;&nbsp;
									<tr> <th><b>Mb:</b></th> <td><span > 9771761584 </span></td></tr>&nbsp;&nbsp;
							
									<tr> <th><b>EMAIL:</b> </th> <td><span > sanjeet852132gmail.com</span> </td></tr>
							
									</div>
															
					</div>  
					<div style=" border:3px solid #CC0000; background:#CC0000; 
					 width:100%;height:auto;
								 border-radius:15px ;  "> 
							<center>
						<form action="" method="post" >
						<table style="text-align:center;"  ><br/><h2 style="color:white;"> For Student!</h2> <br/>
						<tr  ><td > <input type="text" name="s_name"  required placeholder="Student Name" size="40px" height="20px" style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
						<tr><td> <input type="text" name="s_email" required placeholder="Student Email" size="40px" style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr></tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
                        <tr><td> <input type="text" name="s_mb" required placeholder="Student Mobile" size="40px" style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr></tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>

						<tr><td> <input type="text" name="s_subject" required placeholder="Enter Subject" size="40px"style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr></tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
												<tr >
						<th align="center" > <b  style="color:white">Enter Messages:</b></th></tr>
						<tr><td ><textarea rows="6" cols="41" name="s_message"  style="border-radius:20px; text-align:center; "  > </textarea></td> </tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr> </tr><tr> </tr><tr> </tr><tr></tr>
						<tr><td size="30px"> <input type="submit" name="submit" value="Submit" style=" background-color:#FF0000;border-radius:20px; text-align:center; size-height:20px; color:#FFFFFF; font-size:25px;" />  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input type="reset"  value="Reset" style="border-radius:20px; text-align:center; size-height:20px;font-size:25px; background-color:#FF6600; color:#FFFFFF;" /></td> </tr>
						
						</table>
						</form></center
			
					></div>

</div>
