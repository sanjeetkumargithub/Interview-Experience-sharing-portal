<?php 
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="include/style.css" media="all"/>
<style> </style>


<script>
var images =["image/image1.jfif",
				"image/image2.jfif",
				"image/image3.jfif",
				"image/image4.jfif",
				"image/image5.jfif",
				"image/image6.jfif" ];
	var i=0;
	function slides(){
		
	document.getElementById("slideimage").src=images[i];
	if(i<(images.length-1))
		i++;
		else 
		i=0;
		
		} 
	setInterval(slides, 2000)

</script>
</head>

<body>
<div>
<!-- start Header tage-->
<div class="header">
 <center>
 <a href="index.php?search "  style="text-decoration:none; margin-top:20px; float:left; position:inherit;" ><img src="image/mnnit.png" style="height:0%; width:35%; margin-top:-20px;"  /></a>
 <h3 class="head" style="	margin-left:-30px; font-size:180%;"> Interview Experience Sharing Portal! <span style=" "><?php   echo date("d-m-y");  ?><br/> MNNIT COLLEGE</span></h3> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu">

<ul><li> <a href="index.php">Home</a></li>
	<li> <a href="view_student.php">STUDENTS</a></li>
<li> <a href="index.php?exp">COMPANY</a></li>
<li> <a href="stu_account/s_account.php">ACCOUNT</a></li>
	<li> <a href="index.php?contact">CONTACT</a></li>
		
        <li> 
	
	<?php 
	
	 
				if(!isset($_SESSION['s_id']))
				{
						echo	"<a  href='login.php' style='color:white;text-decoration:none; '>Login</a>";}
							else {
                    	    echo	"<a  href='stu_account/logout.php' style='color:#000;text-decoration:none;'>LogOut</a>";}
	?>
	
	</li>
	
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div class="contant">
 <div id="news">  <marquee><h3 > Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>

            <div id="center_"><table style="">
	<img src="image/image1.jfif" width="60%"height="250px;" style="border-radius:10%;" alt="image/image1.jfif" id="slideimage"/>
</table>
		</div>
			
<center>
<?php

if(isset($_GET['exp'])){
include('view_exp_shar.php');

}

if(isset($_GET['signup'])){
include('signup.php');

}

if(isset($_GET['s_account'])){
include('s_acount.php');

}
if(isset($_GET['contact'])){
include('contact.php');
}
if(isset($_GET['particular'])){
$s_is=$_GET['particular'];
$_SESSION['par_stu'];
include('particular_page.php');
}

?>
</center>
<h2  style="color:#000;"> 
 Jojo’s business is at its peak in Mumbai. There are a lot of “candidates” who want to work under her. Jojo likes to conduct interviews before recruiting the “candidates”. Hence, you are required to create a website for the “candidates” in which the users can share their interview experiences.</h2>

 </div></center>



<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"> 
<div style="background-color:#333; height:auto;  margin-top:40px; "> 
	<br/>
    <br/>
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	
	
	
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>