-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 01, 2019 at 02:38 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `interview_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `mb` int(15) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `mb`, `sub`, `message`) VALUES
('sanjeet', 'safgfhg', 68696789, 'hkgjhjgkhg', 'fgdfhdhfhrt'),
('ssssssss', 'ssss', 666, 'yyy', 'xdgfdrhzrhzerh rgesrgerhx\r\njfdch h\r\ngdrg re '),
('hjkjjjjjjj', 'jjjj', 8888, 'jjjjjjhjk', 'hjkglegekrgjrgr '),
('ss', 'kk', 8888, 'hh', 'jgkhklg ');

-- --------------------------------------------------------

--
-- Table structure for table `cumment`
--

DROP TABLE IF EXISTS `cumment`;
CREATE TABLE IF NOT EXISTS `cumment` (
  `com_id` int(255) NOT NULL AUTO_INCREMENT,
  `s_id` int(255) NOT NULL,
  `comment_gmail` text NOT NULL,
  `message` text NOT NULL,
  `date` text NOT NULL,
  `ques_id` int(255) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cumment`
--

INSERT INTO `cumment` (`com_id`, `s_id`, `comment_gmail`, `message`, `date`, `ques_id`) VALUES
(60, 0, 'sanjeet', 'aa', '20-09-19', 1),
(45, 4, 'sanjeet', 'bbbbbb', '20-09-19', 0),
(59, 6, 'sanjeet', 'thanks', '20-09-19', 9),
(57, 2, 'sanjeet', 'xfbdfs', '20-09-19', 0),
(47, 4, 'ran', 'ccccccccc', '20-09-19', 14),
(46, 1, 'ran', 'xxxxxxxxxx', '20-09-19', 0),
(22, 4, 'ran', 'sdgdhtfd', '16-09-19', 0),
(23, 1, 'ran', 'vcgnfgt\r\n', '16-09-19', 0),
(24, 2, 'ran', 'xgdgfdb', '16-09-19', 2),
(25, 2, 'ran', 'xvd\r\n', '17-09-19', 0),
(54, 1, 'ran', 'dgrfhsccccccccccccc', '20-09-19', 0),
(58, 2, 'sanjeet', 'aa', '20-09-19', 2),
(43, 4, 'sanjeet', 'aaaaaa', '20-09-19', 5),
(41, 1, 'sanjeet', 'sannn', '20-09-19', 0),
(56, 6, 'ran', 'thanks', '20-09-19', 11),
(55, 6, 'ran', 'thanks', '20-09-19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `s_id` int(255) NOT NULL AUTO_INCREMENT,
  `ip_add` text NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `s_image` text NOT NULL,
  `s_gmail` text NOT NULL,
  `s_mb` int(15) NOT NULL,
  `s_pro` varchar(20) NOT NULL,
  `s_address` text NOT NULL,
  `c_pin` int(6) NOT NULL,
  `s_pass` text NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `ip_add`, `s_name`, `s_image`, `s_gmail`, `s_mb`, `s_pro`, `s_address`, `c_pin`, `s_pass`) VALUES
(1, '::1', 'ffgg', 'download (3)555.jfif', 'ggjh', 65686, 'gfgjfj', 'fggg kk kukj \r\nghjgj', 4654, ''),
(2, '::1', 'hjk', 'download (1)ss.jfif', 'kl', 89079, 'iku', 'ukj kjhk\r\n ', 89, ''),
(3, '::1', 'hkljhl', 'cc.jfif', 'bjkkhj', 7809, 'gjhgn', 'bhjjbg', 78, ''),
(4, '::1', 'sanjeet', 'download (2)dd.jfif', 'sanjeet', 4455765, 'fhfg', 'zfdhgdfh f h gh\r\ngdf\r\ngfh\r\nghh\r\nt', 65, 'a1'),
(5, '::1', 'rangeet', 'download (3)555.jfif', 'ggjh', 87978, 'hgjhg', 'xsfsdgd\r\ngfdgf\r\ndhf\r\ngfg\r\nfsdh\r\nf\r\n', 67, '11'),
(6, '::1', 'sanjeet', 'download (9).jfif', 'ran', 889, 'vdfg', 'dgterhrh\r\nse bh t\r\nht\r\nh bsh\r\nt h\r\n\r\nhrscxgdf shsr hsrhsf\r\ngesrgrse g rseh\r\nrhtr\r\nj \r\nth\r\ntrh\r\nt sh rsgajkfadw ahfaewfh aef dggerg\r\ng\r\ng\r\nerg\r\nsregreajkglefkljfkdf', 4546, '11'),
(7, '::1', 'ankit', 'download (1).webp', 'ankit', 898, 'ghhj', 'bhjj,xbfd hfghfg hh\r\ngg\r\njg\r\njh', 564, '11'),
(8, '::1', 'ssss', 'download (7).webp', 'sac', 7897, 'jhjkh', 'sdtreteyr', 677, '11'),
(9, '::1', 'nandlal', 'download (2)2.jfif', 'hjjj', 6776, 'hjghh', 'yuiy', 777, '99'),
(10, '::1', 'sanjeet kumar', 'Screenshot (4).png', 'sanjeet', 9999, 'jjjj', 'zvdagva gag\r\nregvs ethsrtj\r\ntg ersh\r\nsrth\r\n s', 8899, '99'),
(11, '::1', 'sanjeet kumar', 'Screenshot (4).png', 'sanjeetku', 9999, 'jjjj', 'xfdhvgj jfjd', 8899, '99'),
(12, '::1', 'sanjeet kumar', 'Screenshot (4).png', 'sanjeetku', 8, 'h', '8nnn', 8, '8');

-- --------------------------------------------------------

--
-- Table structure for table `s_exp_q`
--

DROP TABLE IF EXISTS `s_exp_q`;
CREATE TABLE IF NOT EXISTS `s_exp_q` (
  `ques_id` int(255) NOT NULL AUTO_INCREMENT,
  `s_id` int(255) NOT NULL,
  `co_name` varchar(50) NOT NULL,
  `co_image` text NOT NULL,
  `subject` text NOT NULL,
  `question` text NOT NULL,
  `ans` text NOT NULL,
  `date` text NOT NULL,
  `pdf` text NOT NULL,
  `pdf1` text NOT NULL,
  `pdf2` text NOT NULL,
  `pdf3` text NOT NULL,
  PRIMARY KEY (`ques_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_exp_q`
--

INSERT INTO `s_exp_q` (`ques_id`, `s_id`, `co_name`, `co_image`, `subject`, `question`, `ans`, `date`, `pdf`, `pdf1`, `pdf2`, `pdf3`) VALUES
(1, 0, 'Tata', 'download (2)2.jfif', 'uuuuuuuu', 'uuujkj', 'hgjghg k\r\nfhf\r\nh\r\nhdg\r\nj', '2019-09-25', '', '', '', ''),
(2, 2, 'san', 'download (3)555.jfif', 'aa', 'fff', 'dsfgsgagbser\r\neger', '2019-07-10', '', '', '', ''),
(3, 3, 'amazon', 'images (17).jfif', 'aaa', 'bbbbb', 'dgdsrgsre tg\r\nrh\r\nhsfh\r\nr thjkg  gfgFgfGHrfhFg\r\nf\r\nhfh\r\nrggjdtjfdsfhgtjthrghr\r\ntrhrthtyjhng rg n hhnyt jtrhrst\r\nhrrgrh\r\ntrhtrhtjtyjtj\r\n', '2019-10-01', '', '', '', ''),
(4, 2, 'cf', 'download (5).webp', 'cvb', 'xdgd', 'dfhfg', '2018-08-13', '', '', '', ''),
(5, 4, 'flipcard', 'download (5)1.jfif', 'hhh', 'nnnnn', 'grhdndjyt jy jkoiufjgk\r\njgfufykufuk vhk\r\ngctgucyikguljb kn\r\nbutcnu v kuykui\r\nvuy tvikuio\r\njhjgoio\r\nhjfvi\r\nkjnkg turtckyt jytjhg  yjjvgkn\r\njlh', '2019-09-18', '', '', '', ''),
(15, 6, 'ankit ', 'download (1)ss.jfif', 'aa ', ' aa', 'ans ', '2019-08-28', 'download (5)1.jfif', '', '', ''),
(7, 6, 'fh', 'download (6)xc.jfif', 'dgdh', 'ffn', 'fgnfghn hthhgntjzs\r\nrtutxjtctk', '2019-09-14', '', '', '', ''),
(8, 6, 'f', 'download (4)2.jfif', 'ghj', 'bfgh', 'bgcnh,j', '2019-09-19', 'a1.jfif', '', '', ''),
(9, 6, 'kjjhk', 'download (11)2.jfif', 'ghj', 'bhj', 'hjvhd,zg zhbh \r\ng jd\r\nydbshsklgsj gskghfkj\r\nh\r\nrhs rhstljk', '2019-09-05', 'images (3).jfif', '', '', ''),
(16, 4, 'tata', 'download (5)66.jfif', 'aa', 'jjj', 'jkkhkl;j', '2019-09-19', '', 'download (3).jfif', 'download (2)2.jfif', ''),
(11, 6, 'HJK DG  ', 'shopping (3).webp', 'KJ DGGR  ', '   HJKH', 'XDGSH GRJK\r\nRHTS JJDKLJGDJF BKLFGFKLGKG\r\nEGSTHTRSJ', '2019-09-04 ', 'download (9)1.jfif', '', '', 'download (9)1.jfif'),
(13, 6, 'as                                   ', 'download (4).webp', 'as     xdfbgdfd                                ', '                                   dgfb', 'bgcnh,jss', '2019-09-10', 'shopping (6).webp', 'download (5).jfif', 'shoppingdd.webp', 'download (9).jfif'),
(14, 4, 'jj', 'download (5).jfif', 'jjjjjj', 'jj', 'jjcghfg', '2019-08-28', '', '', 'download (4)45.jfif', 'download (7).jfif');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
