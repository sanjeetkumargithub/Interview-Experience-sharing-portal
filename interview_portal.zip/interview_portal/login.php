<?php 
session_start();
?>
<html>
<head>
<style type="text/css">
body{
	
	margin-top:100px;
	background-color:#60C;}  </style>
</head>
<body>
<form method="post" >
<center><table style='text-align:center' border="8" width="60%px" height="200px" bgcolor="#CC33CC">

<tr>
<td  colspan="6" wordspace='40px' >
<h1 style="background-color:#F0C; text-shadow:2px 5px 3px #F30; color:#F9F;">Interview Experience Sharing Portal! 
<a href="index.php?signup" style="text-decoration:none;">Signup</a>
</h1> 

 </td>
</tr>

<tr>
<th>User Email:</th>

<td> <input type="text" name="email" placeholder="Enter User Email"  style="width:100%;height:35px;" /></td>
</tr>

<tr>
<th>Login Password: </th>

<td> <input type="password" name="password" placeholder="Enter User password" style="width:100%;height:35px;" /> </td>
</tr>

<tr>
<td align="center" colspan="6"  ><input type="submit" name="submit"
 value="Admin Login" style="background-color:#FC9; font-size:24px; color:#F60;"/></td>
</tr>
</table>
</center>
</form>
</body>
</html>

<?php

if(isset($_POST['submit'])){
$user=$_POST['email'];
$pass=$_POST['password'];
include("include/db.php");

$q="select  * from student where s_gmail='$user' && s_pass='$pass' ";

$run_stu=mysqli_query($con,$q);
$check_admin=mysqli_num_rows($run_stu);
	$row=mysqli_fetch_array($run_stu);
	$s_id=$row['s_id'];
if($check_admin==0){
	echo "<script>alert('Password and User ID  is not correct, Please try again! ') </script> " ; 
	echo "<script>window.open('login.php','_self') </script>";
	
}
	if($check_admin==1){
			
			$_SESSION['s_gmail']=$user;
		$_SESSION['s_id']=$s_id;
		echo "<script>window.open('index.php','_self') </script>";
		
			}
		
}
 ?>