<?php 
session_start();



if(isset($_GET['particular'])){
$s_id=$_GET['particular'];
include('include/db.php');
$sel_stu="select * from student where s_id='$s_id'";
$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$s_name=$row['s_name'];
	$s_gmail=$row['s_gmail'];
	$s_mb=$row['s_mb'];
	$s_image=$row['s_image'];
	$s_course=$row['s_pro'];

}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="include/style.css" media="all"/>
<style> </style>

</head>

<body>
<div>
<!-- start Header tage-->
<div class="header">
 <center>
 <a href="index.php?search "  style="text-decoration:none; margin-top:20px; float:left; position:inherit;" ><img src="image/mnnit.png" style="height:0%; width:35%; margin-top:-20px;"  /></a>
 <h2 class="head" style="	margin-left:-30px;"> Interview Experience Sharing Portal! </h2> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu" style="width:100%;">

<ul><li> <a href="index.php">Home</a></li>
	<li> <a href="index.php?view_student">Student Views</a></li>
<li> <a href="index.php?exp">Exp Company</a></li>
<li> <a href="stu_account/s_account.php">Account</a></li>
	<li> <a href="index.php?contact">Contact</a></li>
		
        <li> 
	
	<?php 
	
	 
				if(!isset($_SESSION['s_id']))
				{
						echo	"<a  href='login.php' style='color:white;text-decoration:none; '>Login</a>";}
							else {
                    	    echo	"<a  href='stu_account/logout.php' style='color:white;text-decoration:none;'>LogOut</a>";}
	?>
	
	</li>
	
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div style="margin-top:7.8%; position:relative; width:100%; text-align:left;"> <div id="news">  <marquee><h3  style="position:relative;"> Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>
<div class="contant">


<center>
<div style="position:relative; width:90%;">

<form method="post" action="">
<table align="center" style="background-color:#FFF; color:#0F0; border:solid;" height="auto"width="100%">
<tr>    </tr>
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px;'> <?php echo $s_name;?> &nbsp; &nbsp;Particular Interview Experience Sharing Portal!</h2></tr>

<tr style="color:#333; text-align:center;   text-align:center;  font-size:28px;"> 

<td><a href="view_student.php"  style="text-decoration:none;" > 
<img src='image/<?php echo $s_image; ?>' 
					height='20%' 	width='30%'  style=" animation-timing-function:2s;"/></a> </td>
<td tyle="width:5%;"><?php echo $s_name;?></td>
<td  tyle="width:10%;"><?php echo $s_gmail;?></td>
<td  tyle="width:10%;"><?php echo $s_mb;?></td>


<td tyle="width:10%;"><?php echo $s_course;?></td>

</tr>
	



<tr> 
<th>COM No</th>
<th> IMAGE</th>
<th> NAME</th>
<th> SUBJECT</th>

<th> QUESTION</th>
<th style="width:40%;"> SOLUTION</th>
<th> </th>
<th> Download </th>
<th> PDF</th>
<th> </th>
</tr>
<?php


$sel_stu="select * from s_exp_q  where s_id='$s_id'";
$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$co_name=$row['co_name'];
	$subject=$row['subject'];
	$question=$row['question'];
	$image=$row['co_image'];
	$solution=$row['ans'];
	$pdf=$row['pdf'];
	$pdf1=$row['pdf1'];
	$pdf2=$row['pdf2'];
	$pdf3=$row['pdf3'];

?>


<tr style="color:#999; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><img src='co_image/<?php echo $image; ?>' 
					'height='25%' 	width='35%' /></td>
<td > <span > <?php echo $co_name;?></span> </td>
<td><?php echo $subject;?></td>
<td><?php echo $question;?></td>

<td><?php echo $solution;?></td>
<td><img src='pdf_image/<?php echo $pdf;?>' height='15%' 	width='40%' /><br/>
					<a download="<?php echo $pdf;?>" href="pdf_image/<?php echo $pdf;?>"  style=" text-decoration:none;"><?php echo $pdf;?></a></td>
<td><img src='pdf_image/<?php echo $pdf1;?>' height='15%' 	width='40%' /><br/><a download="<?php echo $pdf1;?>" href="pdf_image/<?php echo $pdf1;?>"  style=" text-decoration:none;"><?php echo $pdf1;?></a></td>
<td><img src='pdf_image/<?php echo $pdf2;?>' height='15%' 	width='40%' /><br/><a download="<?php echo $pdf2;?>" href="pdf_image/<?php echo $pdf2;?>"  style=" text-decoration:none;"><?php echo $pdf2;?></a></td>
<td><img src='pdf_image/<?php echo $pdf3;?>' height='15%' 	width='40%' /><br/><a download="<?php echo $pdf3;?>" href="pdf_image/<?php echo $pdf3;?>"  style=" text-decoration:none;"><?php echo $pdf3;?></a></td>
</tr>
	
<?php }
?>

</table>
</form>

<?php
if(isset($_GET['exp'])){
include('view_exp_shar.php');

}
if(isset($_GET['signup'])){
include('signup.php');

}
if(isset($_GET['view_student'])){
include('view_student.php');

}
if(isset($_GET['s_account'])){
include('s_acount.php');

}
if(isset($_GET['contact'])){
include('contact.php');
}


?>
</div>
</center>

 </div></center>
<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"> 
<div style="background-color:#333; height:auto; "> 
	
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>