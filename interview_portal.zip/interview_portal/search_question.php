<?php 
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="include/style.css" media="all"/>
<style> </style>
<script>
var images =["image/image1.jfif",
				"image/image2.jfif",
				"image/image3.jfif",
				"image/image4.jfif",
				"image/image5.jfif",
				"image/image6.jfif" ];
	var i=0;
	function slides(){
		
	document.getElementById("slideimage").src=images[i];
	if(i<(images.length-1))
		i++;
		else 
		i=0;
		
		} 
	setInterval(slides, 2000)

</script>
</head>

<body>
<div>
<!-- start Header tage-->
<div class="header">
 <center>
 <a href="index.php?search "  style="text-decoration:none; margin-top:20px; float:left; position:inherit;" ><img src="image/mnnit.png" height="102px"
 width="110px"  /></a>
 <h1 class="head" style="	margin-left:-30px;"> Searching  Portal Of Company! <span style=" "><?php   echo date("d-m-y");  ?><br/> MNNIT COLLEGE</span></h1> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu">

<ul><li> <a href="index.php">Home</a></li>
	<li> <a href="index.php?view_student">Student Views</a></li>
<li> <a href="index.php?exp">Exp Company</a></li>
<li> <a href="stu_account/s_account.php">Account</a></li>
	<li> <a href="index.php?contact">Contact</a></li>
		
        <li> 
	
	<?php 
	
	 
				if(!isset($_SESSION['s_id']))
				{
						echo	"<a  href='login.php' style='color:white;text-decoration:none; '>Login</a>";}
							else {
                    	    echo	"<a  href='stu_account/logout.php' style='color:white;text-decoration:none;'>LogOut</a>";}
	?>
	
	</li>
	
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div class="contant">


<div style="margin-top:7%;  width:100%; text-align:left;"> <div id="news">  <marquee><h3 > Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>
		
   </div>
	<img src="image/image1.jfif" width="60%"height="250px; " alt="image/image1.jfif" id="slideimage"/>

<center>
<div style="position:relative; width:90%;">
<!--searching student-->
<div style="position:absolute;">
<div>
<center>
		<form method="get" action="" enctype="meltipart/form-data"  >
		<table style="height:auto; width:80%;">
		<tr>
		<th >
				
		<input type="text" name="search_question"  placeholder=" Search Company Name" style="width:50%; height:40px;		font-size:28px;		text-align:left;" required/>
		
<button name="search"><img src="image/searching.jfif" height="40px" width="40px"  /></button>
		

	</th>
		</tr>
		</table>
		</form>
       
        </center>
		</div>

<form method="post" action="">
<table align="center" style="background-color:#FFF; color:#0F0; border:solid; ;" height="auto"width="100%">
<tr>    </tr>
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px; background-color:#FFF;'> Views All  Interview Experience Sharing Company</h2></tr>
<tr> 
<th>COM No</th>
<th> IMAGE</th>
<th> NAME</th>
<th> SUBJECT</th>

<th> QUESTION</th>
<th> SOLUTION</th>
<th> </th>
<th> Download </th>
<th> PDF</th>
<th> </th>
</tr>
<?php
if(isset($_GET['search'])){

	$search=$_GET['search_question'];
include('include/db.php');
$sel_stu="select * from s_exp_q where co_name like '%$search%'";

$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$ques_id=$row['ques_id'];
	$co_name=$row['co_name'];
	$subject=$row['subject'];
	$question=$row['question'];
	$image=$row['co_image'];
	$solution=$row['ans'];
	$pdf=$row['pdf'];
	$pdf1=$row['pdf1'];
	$pdf2=$row['pdf2'];
	$pdf3=$row['pdf3'];

?>


<tr style="color:#999; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><a href="single_com.php?comment=<?php echo $ques_id;?> "  style="text-decoration:none;" > <img src='co_image/<?php echo $image; ?>' 
					'height='25%' 	width='35%' /></a> </td>
<td > <span > <?php echo $co_name;?></span> </td>
<td><?php echo $subject;?></td>
<td><?php echo $question;?></td>

<td><?php echo $solution;?></td>
<td><img src='pdf_image/<?php echo $pdf; ?>'height='25%' 	width='35%' /><br/>
					<a download="<?php echo $pdf;?>" href="pdf_image/<?php echo $pdf;?>"  style=" text-decoration:none;"><?php echo $pdf;?></a></td>
<td><img src='pdf_image/<?php echo $pdf1; ?>'height='25%' 	width='35%' /><br/><a download="<?php echo $pdf1;?>" href="pdf_image/<?php echo $pdf1;?>"  style=" text-decoration:none;"><?php echo $pdf1;?></a></td>
<td><img src='pdf_image/<?php echo $pdf2; ?>'height='25%' 	width='35%' /><br/><a download="<?php echo $pdf2;?>" href="pdf_image/<?php echo $pdf2;?>"  style=" text-decoration:none;"><?php echo $pdf2;?></a></td>
<td><img src='pdf_image/<?php echo $pdf3; ?>'height='25%' 	width='35%' /><br/><a download="<?php echo $pdf3;?>" href="pdf_image/<?php echo $pdf3;?>"  style=" text-decoration:none;"><?php echo $pdf3;?></a></td>
</tr>
	
<?php }}
?>

</table>
</form>
</div>




<?php

if(isset($_GET['exp'])){
include('view_exp_shar.php');

}
if(isset($_GET['signup'])){
include('signup.php');

}
if(isset($_GET['view_student'])){
include('view_student.php');

}
if(isset($_GET['s_account'])){
include('s_acount.php');

}
if(isset($_GET['contact'])){
include('contact.php');
}


?>
</div>
</center>
<h2  style="color:#000; position:static; margin-top:100px;"> 
 Jojo’s business is at its peak in Mumbai. There are a lot of “candidates” who want to work under her. Jojo likes to conduct interviews before recruiting the “candidates”. Hence, you are required to create a website for the “candidates” in which the users can share their interview experiences.</h2>

 </div></center>



<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"> 
<div style="background-color:#333; height:auto; "> 
	
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	
	
	
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>