
<?php
@session_start();
include ('include/db.php');
include ('fun/fun.php');
if(isset($_POST['submit'])){
	$s_name=$_POST['s_name'];
	$s_gmail=$_POST['s_email'];
	
	$s_pro=$_POST['pro'];
	$contact=$_POST['s_mb'];
	$pass=$_POST['s_pass'];
	$co_pass=$_POST['co_pass'];
	$s_code=$_POST['s_code'];
	$s_address=$_POST['s_add'];
	if($pass!=$co_pass)
	{
				echo "<script> alert('This Password is not be same! ') </script>";
		echo "<script>window.open('index.php?signup','_self') </script>";
		
	}
	else 
	{ //$co_pas=password_hash($pass, algo:PASSWORD_BCRYPT);
	}
$s_img = $_FILES['image']['name'];
$s_img_tmp=$_FILES['image']['tmp_name'];

	move_uploaded_file($s_img_tmp,"image/$s_img");
		
	
	
	$qs="select * from student where s_gmail='$s_gmail'";
	$res=mysqli_query($con,$qs);
	$num=mysqli_num_rows($res);
	if($num>0){
				echo "<script> alert('This Email Id is diferent Input! ') </script>";
		echo "<script>window.open('index.php?signup','_self') </script>";
		
	}

	$s_ip=getIp();

	$cu_q="insert into student (ip_add,s_name,s_image,s_gmail,s_mb,s_pro,s_address,c_pin,s_pass)
	values('$s_ip','$s_name','$s_img','$s_gmail','$contact','$s_pro','$s_address','$s_code','$pass')";
	
	$result=mysqli_query($con,$cu_q);
	
		if($result)
{	
$_SESSION['s_gmail']=$s_gmail;
$s_g=$_SESSION['s_gmail'];
$sel_stu="select * from student where s_gmail='$s_g' ";
$stu=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($stu);
	$row=mysqli_fetch_array($stu);
$s_id=$row['s_id'];
$_SESSION['s_id']=$s_id;

echo "<script> alert('Your Account Successfuly submits! ') </script>";
		echo "<script>window.open('index.php','_self') </script>";
}
else

	  echo "<script>window.open('index.php?signup','_self') </script>";

}

?>  
<center>
<div style="width:100%; text-align:center;">
                   <form method="post" action="" enctype="multipart/form-data">
               <br/>    <table  style=" margin-left:10%;background-color:#FFCCCC; width:80%;heigh:auto;"    >
                 
                 
                   <tr  ><td colspan='10' align="center"  color="gray" style="text-shadow:2px 5px 0px #F0C;" bgcolor='red'><h1 > Create Students  Account! </h1> </td> </tr>
                   <tr></tr><tr></tr><tr></tr>
                     <tr> <th align="left">Students Name:</th>
                     	  <td><input type="text" name="s_name" placeholder="Enter Students Name! " required/></td>	
                     </tr>
                 
                             	<tr><th  align="left">Select Our Image:  </th>
            	 <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="image" required /> </td> 
            </tr>
                     <tr> <th align="left">Students Email:</th>
                     	  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="s_email" placeholder="Enter  Students email!" size='33' required/></td>	
                     </tr>
                      <tr> <th align="left">Mobile No:</th>
                     	  <td><input type="text" name="s_mb" placeholder="Enter Mobile Number!" required/></td>	
                     </tr>
					 
                       <tr> <th align="left">Students Program:</th>
                     	  <td> <input  type="text" name="pro" placeholder="Enter program Course!" required/> 
                          		
                           </td>	
                     </tr>
                    
					
	               <tr> <th align="left">Students PIN Code:</th>
                     	  <td><input type="text" name="s_code" placeholder="Enter PIN Code!" required/></td>	
                     </tr>
                     
                     	               <tr> <th align="left">Students Password:</th>
                     	  <td><input type="text" name="s_pass" placeholder="Enter Password!" required/></td>	
                     </tr>
                     <tr> <th align="left">Conform Password:</th>
                     	  <td><input type="text" name="co_pass" placeholder="Conform Password!" required/></td>	
                     </tr>
                     <tr> <th align="left">Students Address:</th>
                     	  <td colspan="15"><textarea name="s_add" cols='35' rows="10" required ></textarea></td>	
                     </tr>
                       
                      <tr> 
                     	  <td colspan="10" align="center" style="background-color:#FF99CC; "> <input type="submit" name="submit"  style="width:30%; background-color:#FF6600; font-size:26px;"value="Register Know"/></td>	
                     </tr>
                   
                   </table>
                   </form>

                   </div>

</center>