<?php 
session_start();


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="include/style.css" media="all"/>
<style> </style>

</head>

<body  >
<div>
<!-- start Header tage-->
<div class="header">
 <center>
 <a href="index.php?search "  style="text-decoration:none; margin-top:20px; float:left; position:inherit;" ><img src="image/mnnit.png" height="102px"
 width="110px"  /></a>
 <h1 class="head" style="	margin-left:-30px;"> <?php  ?> All Solution! <span style=" "><?php   echo date("d-m-y");  ?><br/> MNNIT COLLEGE</span></h1> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu">

<ul><li> <a href="index.php">Home</a></li>
	<li> <a href="index.php?view_student">Student Views</a></li>
<li> <a href="index.php?exp">Exp Company</a></li>
<li> <a href="stu_account/s_account.php">Account</a></li>
	<li> <a href="index.php?contact">Contact</a></li>
		
        <li> 
	
	<?php 
	
	 
				if(!isset($_SESSION['s_id']))
				{
						echo	"<a  href='login.php' style='color:white;text-decoration:none; '>Login</a>";}
							else {
                    	    echo	"<a  href='stu_account/logout.php' style='color:white;text-decoration:none;'>LogOut</a>";}
	?>
	
	</li>
	
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div class="contant">
<div  style=" background-color:#CCC;">

<div style="margin-top:7%; position:relative; width:100%; text-align:left;"> <div id="news">  <marquee><h3 > Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>
		
   </div>
        

 	

<center>
<div >
<!--searching student-->
<div style="">
<div></div>

<?php
if(isset($_GET['comment'])){
	$ques_id=$_GET['comment'];
	$_SESSION['ques_id']=$ques_id;
	if(!isset($_SESSION['s_gmail']))
{echo "<script> alert('Please Login Our Account Than Use The Comment Box! ') </script>";
echo "<script>window.open('login.php','_self') </script>";}

	?>
<center>
<form action="comment.php" method="post">
<table style="width:80%; height:100%; text-align:center; position:relative;">
<tr>
	 <td colspan="15"><textarea name="comment" cols='35' rows="6" required ></textarea></td></tr>
     <tr><td size="30px"> <input type="submit" name="submit_com" value="Comment" style=" background-color:#0F0;border-radius:20px; text-align:center; size-height:20px; color:#FFFFFF; font-size:25px;" />  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input type="reset"  value="Cancel" style="border-radius:20px; text-align:center; size-height:20px;font-size:25px; background-color:#FF6600; color:#FFFFFF;" /></td> </tr>
					
	</table>
</form>
</center>	
	<?php
	}


if(isset($_GET['single_q'])){
?>
<center>
<form method="post" action="">
<table align="center" style="background-color:#FFF; color:#0F0; border:solid; text-align:center;" height="auto"width="100%">
<tr>    </tr>
<tr> <h2 colspan='8' align="center" style='color:#FF0000; background-color:#6F6; font-style:italic; font-size:36px;wordspace:30px;'>  Sharing Company</h2></tr>
<tr> 
<th>COM No</th>
<th> IMAGE</th>
<th> NAME</th>
<th> SUBJECT</th>

<th> QUESTION</th>
<th> SOLUTION</th>
<th>Comment </th>



<th> </th>
<th> Download </th>
<th> PDF</th>
<th> </th>
</tr>
<?php
	$search=$_GET['single_q'];
include('include/db.php');
$sel_stu="select * from s_exp_q where ques_id='$search'";

$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$co_name=$row['co_name'];
	$subject=$row['subject'];
	$question=$row['question'];
	$image=$row['co_image'];
	$solution=$row['ans'];
	$ques_id=$row['ques_id'];
	
	
	
	$pdf=$row['pdf'];
	$pdf1=$row['pdf1'];
	$pdf2=$row['pdf2'];
	$pdf3=$row['pdf3'];
?>


<tr style="color:#999; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td  style="width:20%;"><a href="particular_page.php?particular=<?php  echo $s_id;?> "   style="text-decoration:none;" > <img src='co_image/<?php echo $image; ?>' 
					'height='25%' 	width='35%' /></a> </td>
<td > <span > <?php echo $co_name;?></span> </td>
<td><?php echo $subject;?></td>
<td><?php echo $question;?></td>   
 

<td   style="width:20%;"><?php echo $solution;?></td>
<td><a href="single_com.php?comment=<?php  echo $ques_id;?>"  style="text-decoration:none;" >comment</a> </td>
<td><a download="<?php echo $pdf;?>" href="pdf_image/<?php echo $pdf;?>"  style=" text-decoration:none;"><?php echo $pdf;?></a></td>
<td><a download="<?php echo $pdf1;?>" href="pdf_image/<?php echo $pdf1;?>"  style=" text-decoration:none;"><?php echo $pdf1;?></a></td>
<td><a download="<?php echo $pdf2;?>" href="pdf_image/<?php echo $pdf2;?>"  style=" text-decoration:none;"><?php echo $pdf2;?></a></td>
<td><a download="<?php echo $pdf3;?>" href="pdf_image/<?php echo $pdf3;?>"  style=" text-decoration:none;"><?php echo $pdf3;?></a></td>
</tr>
<?php }}
?>

</table>
</form></center>
</div>




<?php

if(isset($_GET['exp'])){
include('view_exp_shar.php');

}
if(isset($_GET['signup'])){
include('signup.php');

}
if(isset($_GET['view_student'])){
include('view_student.php');

}
if(isset($_GET['s_account'])){
include('s_acount.php');

}
if(isset($_GET['contact'])){
include('contact.php');
}


?>
</div>
</center>
<h2  style="color:#000; position:static; margin-top:100px;"> 
 Jojo’s business is at its peak in Mumbai. There are a lot of “candidates” who want to work under her. Jojo likes to conduct interviews before recruiting the “candidates”. Hence, you are required to create a website for the “candidates” in which the users can share their interview experiences.</h2>
</div>
 </div></center>



<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"   style="position:relative; margin-top:450px;"> 
<div style="background-color:#333; height:auto; "> 
	
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	
	
	
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>