<?php 
session_start();
include('../include/db.php');
if(isset($_GET['delete']))
{
	$com_id=$_GET['delete'];
	$q="delete from cumment where com_id='$com_id'";
	$result=mysqli_query($con,$q);
		if($result)
{	

		echo "<script>window.open('comment.php','_self') </script>";
}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="../include/style.css" media="all"/>
<style> </style>

</head>

<body>
<div>
<!-- start Header tage-->
<div class="header">
 <center>
 <a href="index.php?search "  style="text-decoration:none; margin-top:20px; float:left; position:inherit;" ><img src="../image/mnnit.png" style="height:0%; width:35%; margin-top:-20px; border-radius:50%;"  /></a>
 <h5 class="head" style="	margin-left:-30px;font-size:150%;"> Interview Experience Sharing Portal! <span style=" "><?php   echo date("d-m-y");  ?><br/> MNNIT COLLEGE</span></h5> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu" style="width:100%;">

<ul><li> <a href="../index.php">Home</a></li>
	<li> <a href="../view_student.php">View Student</a></li>
<li> <a href="s_account.php?exp">Insert Exp</a></li>
<li> <a href="s_account.php">Account</a></li>
	<li> <a href="share_comment.php">Share Comment</a></li>
		
        <li> 
	
	<?php 
	
	 
				if(!isset($_SESSION['s_id']))
				{
						echo	"<a  href='../login.php' style='color:white;text-decoration:none; '>Login</a>";}
							else {
                    	    echo	"<a  href='logout.php' style='color:white;text-decoration:none;'>LogOut</a>";}
	?>
	
	</li>
	
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div style="margin-top:7.8%;  width:100%; text-align:left;"> <div id="news">  <marquee><h3  style="position:relative;"> Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>
<div class="contant">



		
   </div>

<center>


<div style="position:relative; width:90%;">


<center>
<?php
if(isset($_GET['mail'])){
	$to_mail=$_GET['mail'];
	$_SESSION['to_email']=$to_mail;
?>
<center>
<form action="sendmail.php" method="post">
<table style="width:30%; height:300px;">
<tr>
	 <td colspan="15"><textarea name="message" cols='35' rows="6" required ></textarea></td></tr>
     <tr><td size="30px"> <input type="submit" name="mailsend" value="Send" style=" background-color:#0F0;border-radius:20px; text-align:center; size-height:20px; color:#FFFFFF; font-size:25px;" />  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input type="reset"  value="Cancel" style="border-radius:20px; text-align:center; size-height:20px;font-size:25px; background-color:#FF6600; color:#FFFFFF;" /></td> </tr>
					
	</table>
</form>
</center>

<?php }?>
<form method="post" action="">
<table align="center" style="background-color:#FFF; border:solid;  margin-left:-35px;" height="auto"width="109%">
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px;'> Views All  Comment of Question!</h2></tr>
<tr> 
<th> Stu No</th>
<th> NAME</th>
<th> Email</th>

<th> Mb.No</th>
<th> Comment</th>
<th> Mail</th>
<th> Delete</th>

</tr>
<?php
include('../include/db.php');
$gmail=$_SESSION['s_gmail'];


$sel_stu="select * from student where s_gmail='$gmail'";
$run_pro=mysqli_query($con,$sel_stu);
mysqli_num_rows($run_pro);

	$row=mysqli_fetch_array($run_pro);
	$user_id=$row['s_id'];
	
$sel_select="select * from cumment where  s_id='$user_id'";
$run_com=mysqli_query($con,$sel_select);
$num1=mysqli_num_rows($run_com);

for($i=1;$i<=$num1;$i++){
	
	$row=mysqli_fetch_array($run_com);
	$com_id=$row['com_id'];
	$message=$row['message'];
	$date=$row['date'];
	$ques_id=$row['ques_id'];
	$com_gmail=$row['comment_gmail'];
	$s_id=$row['s_id'];
	
	$sel_stu1="select * from student where s_gmail='$com_gmail'";
$run_pro2=mysqli_query($con,$sel_stu1);
mysqli_num_rows($run_pro2);

	$row=mysqli_fetch_array($run_pro2);
	$s_name=$row['s_name'];
	$s_mb=$row['s_mb'];
?>


<tr style="color:#666; text-align:center"> 
<td style="color:black;"> <?php echo $user_id;?></td>
<td><?php echo $s_name;?></td>
<td><?php echo $com_gmail;?></td>
<td><?php echo $s_mb;?></td>


<td><?php echo $message;?></td>
<td><a href="comment.php?mail=<?php  echo $com_gmail; ?>" style="text-decoration:none;">MailSend</a></td>
<td><a href="comment.php?delete=<?php  echo $com_id; ?>" style="text-decoration:none;">Delete</a></td>
</tr>
	
<?php }

?>
</table>
</form>
<?php

if(isset($_GET['exp'])){
include('../view_exp_shar.php');

}
if(isset($_GET['signup'])){
include('../signup.php');

}

if(isset($_GET['s_account'])){
include('s_acount.php');

}
if(isset($_GET['contact'])){
include('../contact.php');
}
if(isset($_GET['particular'])){
$s_is=$_GET['particular'];
$_SESSION['par_stu'];
include('particular_page.php');
}

?>
</div>
</center>
<h2  style="color:#000; position:static; margin-top:100px;"> 
 Jojo’s business is at its peak in Mumbai. There are a lot of “candidates” who want to work under her. Jojo likes to conduct interviews before recruiting the “candidates”. Hence, you are required to create a website for the “candidates” in which the users can share their interview experiences.</h2>

 </div></center>



<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"> 
<div style="background-color:#333; height:auto; "> 
	
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	
	
	
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>