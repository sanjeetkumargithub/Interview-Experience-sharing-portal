
<?php
session_start();
include ('../include/db.php');
include ('../fun/fun.php');


if(isset($_GET['edit'])){
	$ques_id=$_GET['edit'];
	$_SESSION['ques_id']=$ques_id;
$sel_stu="select * from s_exp_q  where ques_id='$ques_id'";
$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$co_name=$row['co_name'];
	$subject=$row['subject'];
	$ques=$row['question'];
	$image=$row['co_image'];
	$solution=$row['ans'];
	$date=$row['date'];
	$pdf=$row['pdf'];
	$pdf1=$row['pdf1'];
	$pdf2=$row['pdf2'];
	$pdf3=$row['pdf3'];
$_SESSION['date']=$date;
$_SESSION['co_image']=$image;
$_SESSION['pdf']=$pdf;
$_SESSION['pdf1']=$pdf1;
$_SESSION['pdf2']=$pdf2;
$_SESSION['pdf3']=$pdf3;

}

if(isset($_POST['submit'])){

	$co_name=$_POST['co_name'];
	$subject=$_POST['subject'];
	$ques=$_POST['ques'];
	$experience=$_POST['experience'];
	$dateup=$_POST['dateup'];

$co_img = $_FILES['co_image']['name'];
$s_img_tmp=$_FILES['co_image']['tmp_name'];

	move_uploaded_file($s_img_tmp,"../co_image/$co_img");

$pdf_img = $_FILES['pdf']['name'];
$s_img_tmpf=$_FILES['pdf']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img");

$pdf_img1 = $_FILES['pdf1']['name'];
$s_img_tmpf=$_FILES['pdf1']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img1");

$pdf_img2 = $_FILES['pdf2']['name'];
$s_img_tmpf=$_FILES['pdf2']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img2");

$pdf_img3 = $_FILES['pdf3']['name'];
$s_img_tmpf=$_FILES['pdf3']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img3");



if( $dateup==''){
	$dateup=$_SESSION['date'];
	
	}
if( $co_img==''){
	$co_img=$_SESSION['co_image'];
	
	}
		if( $pdf_img==''){
	$pdf_img=$_SESSION['pdf'];
	}
	if( $pdf_img1==''){
	$pdf_img1=$_SESSION['pdf1'];
	}
	if( $pdf_img2=='' ){
	$pdf_img2=$_SESSION['pdf2'];
	}
	if( $pdf_img3==''){
	$pdf_img3=$_SESSION['pdf3'];
	}
		
	$ques_id=$_SESSION['ques_id'];

	$exp_q="update s_exp_q  set   s_id='$s_id',co_name='$co_name',co_image='$co_img',subject='$subject',question='$ques',ans='$experience',date='$dateup',pdf='$pdf_img',pdf1='$pdf_img1',pdf2='$pdf_img2',pdf3='$pdf_img3' where ques_id='$ques_id' ";
	
	$result=mysqli_query($con,$exp_q);
	
		if($result)
{	

echo "<script> alert('Your Experience Successfuly submits!') </script>";
		echo "<script>window.open('s_account.php?insert_exp','_self') </script>";
}
else
{
	$s=$_SESSION['ques_id'];
echo "<script> alert('Your Experience Cannot be submits!     ') </script>";
		echo "<script>window.open('edit_post.php?edit=$s','_self') </script>";

}
}

?>  
<center>
<div style=" width:100%; ">
                   <form method="post" action="" enctype="multipart/form-data">
               <br/>    <table  style=" background-color:#FFCCCC; text-align:center; width:80%;heigh:auto;">
                 
                 
                   <tr  ><td colspan='10' align="center"  color="gray" style="text-shadow:2px 5px 0px #F0C;" bgcolor='red'><h1 > Only Final /Third Year Student can Post their Experience! </h1> </td> </tr>
                   <tr></tr><tr></tr><tr></tr>
                     
                       <tr> <th align="left">Company Name:</th>
                     	  <td><input type="text" name="co_name" value="<?php   echo $co_name;?> " required/></td>	
                     </tr>
                 
                             	<tr><th  align="left">Select Company Image:  </th>
            	 <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 &nbsp;	<input type='file' name="co_image"   value="<?php echo $image; ?>" />
				 <img src="../co_image/<?php echo "$image";?>"   height="60px" width="50px"/> </td>  
            
            </tr>
                     <tr> <th align="left"> Interview Subject:</th>
                     	  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="subject" value="<?php   echo $subject;?> " size='33' required/></td>	
                     </tr>
                      <tr> <th align="left">Interview Question:</th>
                     	  <td><input type="text" name="ques" value=" <?php   echo $ques; ?>" /></td>	
                     </tr>
					 
                                         <tr> <th align="left">Experience OF Interviews:</th>
                     	  <td colspan="15"><textarea name="experience" cols='40' rows="12" required ><?php   echo $solution;?></textarea></td>	
                     </tr>
					 <tr> <th align="left"> PDF  FILE:</th>
                     	   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="pdf"   value="<?php echo $pdf; ?>" />
				 <img src="../pdf_image/<?php echo "$pdf";?>"   height="60px" width="50px"/> 
                 <input type='file' name="pdf1"   value="<?php echo $pdf1; ?>" />
				 <img src="../pdf_image/<?php echo "$pdf1";?>"   height="60px" width="50px"/> 
                           </td> </tr> <tr> <th></th> <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="pdf2"   value="<?php echo $pdf; ?>" />
				 <img src="../pdf_image/<?php echo "$pdf2";?>"   height="60px" width="50px"/> <input type='file' name="pdf3"   value="<?php echo $pdf3; ?>" />
				 <img src="../pdf_image/<?php echo "$pdf3";?>"   height="60px" width="50px"/> </td>	
                     </tr>
                
	                 
                       <tr><th align="left"> DOC/DOCX FILE:</th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='DOC/DOCX' name="doc1"  /><input accept='DOC/DOCX' name="doc2"  /></td></tr>
                        <tr> <th align="left">Interview Date:</th>
                     	  <td><input type="date" name="dateup" />
                          <input type="text" name="date" value="<?php  echo $date;?> "/></td>	
                     </tr>
                  
                      <tr> 
                     	  <td colspan="10" align="center" style="background-color:#FF99CC; "> <input type="submit" name="submit"  style="width:60%; background-color:#FF6600; font-size:26px;"value="Register Know"/></td>	
                     </tr>
                   
                   </table>
                   </form>

                   </div>

</center>