
<?php
@session_start();
include ('../include/db.php');
include ('../fun/fun.php');
if(isset($_POST['submit'])){

	$co_name=$_POST['co_name'];
	$subject=$_POST['subject'];
	$question=$_POST['question'];
	$experience=$_POST['experience'];
	$date=$_POST['date'];

$co_img = $_FILES['image']['name'];
$s_img_tmp=$_FILES['image']['tmp_name'];

	move_uploaded_file($s_img_tmp,"../co_image/$co_img");

$pdf_img = $_FILES['pdf']['name'];
$s_img_tmpf=$_FILES['pdf']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img");

$pdf_img1 = $_FILES['pdf1']['name'];
$s_img_tmpf=$_FILES['pdf1']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img1");

$pdf_img2 = $_FILES['pdf2']['name'];
$s_img_tmpf=$_FILES['pdf2']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img2");

$pdf_img3 = $_FILES['pdf3']['name'];
$s_img_tmpf=$_FILES['pdf3']['tmp_name'];
	move_uploaded_file($s_img_tmpf,"../pdf_image/$pdf_img3");
		
	$s_id=$_SESSION['s_id'];

	$exp_q="insert into s_exp_q (s_id,co_name,co_image,subject,question,ans,date,pdf,pdf1,pdf2,pdf3)
	values('$s_id','$co_name','$co_img','$subject','$question','$experience','$date','$pdf_img','$pdf_img1','$pdf_img2','$pdf_img3')";
	
	$result=mysqli_query($con,$exp_q);
	
		if($result)
{	

echo "<script> alert('Your Experience Successfuly submits! ') </script>";
		echo "<script>window.open('s_account.php?insert_exp','_self') </script>";
}
else

echo "<script> alert('Your Experience Cannot be submits! ') </script>";
		echo "<script>window.open('s_account.php?insert_exp','_self') </script>";
}

?>  
<div style=" width:100%; ">
                   <form method="post" action="" enctype="multipart/form-data">
               <br/>    <table  style=" margin-top:-200px;background-color:#FFCCCC; width:80%;heigh:auto;" width="500px;" height="auto"   >
                 
                 
                   <tr  ><td colspan='10' align="center"  color="gray" style="text-shadow:2px 5px 0px #F0C;" bgcolor='red'><h1 > Only Final /Third Year Student can Post their Experience! </h1> </td> </tr>
                   <tr></tr><tr></tr><tr></tr>
                     
                       <tr> <th align="left">Company Name:</th>
                     	  <td><input type="text" name="co_name" placeholder="Enter Company Name! " required/></td>	
                     </tr>
                 
                             	<tr><th  align="left">Select Company Image:  </th>
            	 <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="image" required /> </td> 
            </tr>
                     <tr> <th align="left"> Interview Subject:</th>
                     	  <td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="subject" placeholder="Enter  Interview Subject!" size='33' required/></td>	
                     </tr>
                      <tr> <th align="left">Interview Question:</th>
                     	  <td><input type="text" name="question" placeholder="Enter Interview Question!" required/></td>	
                     </tr>
					 
                                         <tr> <th align="left">Experience OF Interviews:</th>
                     	  <td colspan="15"><textarea name="experience" cols='40' rows="12" required ></textarea></td>	
                     </tr>
					 <tr> <th align="left"> PDF  FILE:</th>
                     	   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="pdf" /><input type='file' name="pdf1" />
                           </td> </tr> <tr> <th></th> <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='file' name="pdf2"  /><input type='file' name="pdf3"  /></td>	
                     </tr>
                
	                 
                       <tr><th align="left"> DOC/DOCX FILE:</th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='DOC/DOCX' name="doc1"  /><input accept='DOC/DOCX' name="doc2"  /></td></tr>
                        <tr> <th align="left">Interview Date:</th>
                     	  <td><input type="date" name="date" placeholder="Enter Interview Date!" required/></td>	
                     </tr>
                  
                      <tr> 
                     	  <td colspan="10" align="center" style="background-color:#FF99CC; "> <input type="submit" name="submit"  style="width:20%; background-color:#FF6600; font-size:26px;"value="Submit Know"/></td>	
                     </tr>
                   
                   </table>
                   </form>

                   </div>

