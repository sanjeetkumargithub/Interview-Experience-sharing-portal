<?php  
@session_start();
if(!isset($_SESSION['s_gmail']))
{
echo "<script>window.open('../login.php','_self') </script>";}
else {
include ('../include/db.php');


if(isset($_GET['delete_q'])){
	$ques_id=$_GET['delete_q'];

$sel_stu="delete from s_exp_q  where ques_id='$ques_id'";
$result=mysqli_query($con,$sel_stu);
		if($result)
{	

echo "<script> alert('Your sharing Experience is Deleted!') </script>";
		echo "<script>window.open('s_account.php?view_exp','_self') </script>";
}
}
$s_g=$_SESSION['s_gmail'];
$q="select  * from student where s_gmail='$s_g' ";

$run_stu=mysqli_query($con,$q);
$check_admin=mysqli_num_rows($run_stu);
	$row=mysqli_fetch_array($run_stu);
	$s_name=$row['s_name'];
	$s_gmail=$row['s_gmail'];
	$s_image=$row['s_image'];

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Interview Experience sharing Portal</title>
<script  type="text/javascript"> </script>
<link rel="stylesheet" href="../include/style.css" media="all"/>
<style> </style>
<script>
var images =["../image/image1.jfif",
				"../image/image2.jfif",
				"../image/image3.jfif",
				"../image/image4.jfif",
				"../image/image5.jfif",
				"../image/image6.jfif" ];
	var i=0;
	function slides(){
		
	document.getElementById("slideimage").src=images[i];
	if(i<(images.length-1))
		i++;
		else 
		i=0;
		
		} 
	setInterval(slides, 2000)

</script>
</head>

<body>
<div>
<!-- start Header tage-->
<div class="header">
 <center><h1 class="head"> <?php echo $s_name;?> Personal Account! <span style=" margin-left:15%;"><?php   echo date("d-m-y");?> &nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='../image/<?php echo $s_image; ?>' 
					height='57px' 	width='80px'  style="border-radius:50%;"/></span></h1> </center> 

</div>
<!-- End Header tage-->

<!-- start Menu tage-->
<center><div class="menu">

<ul><li> <a href="../index.php">Home</a></li>
	<li> <a href="s_account.php?view_exp">Views Experience</a></li>
<li> <a href="s_account.php?exp">Insert Experience</a></li>
<li> <a href="comment.php">View Comment</a></li>
	<li> <a href="s_account.php?view_con">View Contact</a></li>
		<li> <a href="share_comment.php">Share Comment</a></li>
	</ul>
	
</div></center>
<!-- End Menu  tage-->

<!-- start contant tage-->
<center>
<div class="contant">



<div style="margin-top:60px; margin-left:-10px; position:relative; width:100%; text-align:left;"> <div id="news">  <marquee><h3 > Interview Experience Sharing Portal!   &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp; There are a lot of “candidates”<b class="news_style"> News</b> who want to work under her. Jojo likes to conduct interviews before recruiting the<b class="news_style"> News</b> “candidates”. Hence, you are required to create a website for the <b class="news_style"> News</b>“candidates” in which the users can share <b class="news_style"> News</b>their interview experiences <b class="news_style"> News</b>&nbsp; 2019</h3>
			 </marquee> </div>
		
        
        
	

<center>



<?php
if(isset($_GET['contact_email'])){
	$to_email=$_GET['contact_email'];
	$_SESSION['to_email']=$to_email;
?>
<center>
<form action="sendmail.php"  method="get">
<table style="width:30%; height:300px;">
<tr>
	 <td colspan="15"><textarea name="message" cols='35' rows="6" required ></textarea></td></tr>
     <tr><td size="30px"> <input type="submit" name="contact_send" value="Comment" style=" background-color:#0F0;border-radius:20px; text-align:center; size-height:20px; color:#FFFFFF; font-size:25px;" />  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input type="reset"  value="Cancel" style="border-radius:20px; text-align:center; size-height:20px;font-size:25px; background-color:#FF6600; color:#FFFFFF;" /></td> </tr>
					
	</table>
</form>
</center>	
	<?php
	}
?>



<img src="../image/image1.jfif" width="60%"height="250px; "  style="border-radius:10%;"alt="i../mage/image1.jfif" id="slideimage"/>
<div style="position:relative; width:90%;">
<?php

if(isset($_GET['view_exp'])){
include('view_exp_shar.php');

} 
if(isset($_GET['exp'])){
include('exp_shair_q.php');

}
if(isset($_GET['view_con'])){
include('view_contact.php');

}
?>
</div>
</center>
<h2  style="color:#000; position:static; margin-top:100px;"> 
 Jojo’s business is at its peak in Mumbai. There are a lot of “candidates” who want to work under her. Jojo likes to conduct interviews before recruiting the “candidates”. Hence, you are required to create a website for the “candidates” in which the users can share their interview experiences.</h2>

 </div></center>



<!-- End contant tage-->

<!-- start Footer tage-->

<div class="footer"> 
<div style="background-color:#333; height:auto; "> 
	
	<h2 style="text-align:center;">&nbsp;  &copy; Contant &nbsp;&euro; &nbsp; 2019 Developed By:-
	&nbsp; &curren; &nbsp;<span  id="sanjeet">Sanjeet Kumar</span> Mb &rArr; 9771761584</h2>
	
	
	
	</div>
	
    </div>
<!-- End Footer tage-->

</div>
</body>
</html>
<?php  }?>