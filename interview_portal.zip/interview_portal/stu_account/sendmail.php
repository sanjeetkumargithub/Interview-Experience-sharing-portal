<?php  
session_start();

			if(isset($_GET['mailsend'])){	
				
					//<!--Getting Student Email send code-->	
						$from=$_SESSION['s_gmail'];
						$subject='Responce Your Comment:';
						$messages=$_GET['message'];
						
						
						$to_email=$_SESSION['to_email'];
						mail($to_email,$subject,$messages,$from);
echo "<script>window.open('comment.php','_self') </script>";

			}
			
					//<!--Getting Student Email send code-->			
						if(isset($_GET['contact_send'])){	
				
							$msg=$_GET['message'];
						$from_email=$_SESSION['to_email'];
						$to_email=$_SESSION['s_gmail'];
						include('../include/db.php');
						$sel_select="select * from contact where email='$from'";
$run_com=mysqli_query($con,$sel_select);
$num1=mysqli_num_rows($run_com);

	$row=mysqli_fetch_array($run_com);


	$subject=$row['sub'];

						$messages=$_GET['message'];
						$to_email=$_SESSION['s_gmail'];
						mail($to_email,$subject,$msg,$from_email);
echo "<script>window.open('account.php?view_con','_self') </script>";

			}
?>