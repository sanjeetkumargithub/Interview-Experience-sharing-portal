<?php  
@session_start();
if(!isset($_SESSION['s_gmail']))
{
echo "<script>window.open('../login.php','_self') </script>";}
else {
include('../include/db.php');
?>
<form method="post" action="">
<table align="center" style="background-color:#FFF; border:solid;  margin-left:-35px;" height="auto"width="109%">
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px;'> Views All  Contact of Student!</h2></tr>
<tr> 
<th> No</th>
<th> NAME</th>
<th> Email</th>

<th> Mb.No</th>
<th> Subject</th>
<th> Message</th>
<th> Sendmail</th>

</tr>
<?php

$sel_select="select * from contact";
$run_com=mysqli_query($con,$sel_select);
$num1=mysqli_num_rows($run_com);

for($i=1;$i<=$num1;$i++){
	
	$row=mysqli_fetch_array($run_com);
	$name=$row['name'];
	$email=$row['email'];
	$mb=$row['mb'];
	$message=$row['message'];
	$subject=$row['sub'];

?>


<tr style="color:#666; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><?php echo $name;?></td>
<td><?php echo $email;?></td>
<td><?php echo $mb;?></td>

<td><?php echo $subject;?></td>
<td><?php echo $message;?></td>
<td><a href="account.php?contact_email=<?php  echo $email; ?>" style="text-decoration:none;">MailSend</a></td>
</tr>
	
<?php
 }

?>
</table>
</form>

</div>
</center>

 </div></center>



<!-- End contant tage-->


</div>
</body>
</html>
<?php }
?>