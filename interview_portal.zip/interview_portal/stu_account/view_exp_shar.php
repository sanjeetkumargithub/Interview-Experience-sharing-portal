<?php 
@session_start();


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Interview Experience Sharing Portal!</title>

<style type="text/css">

</style>
</head>



<body>
<form method="post" action="">
<table  style="background-color:#C9C;border:solid; text-align:center;" height="auto"width="90%">
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px;'> Views All  Interview Experience Sharing Students</h2></tr>
<tr> 
<th> Exp No</th>
<th> Image</th>
<th> NAME</th>
<th>SUBJECT</th>

<th> QUESTION</th>
<th> SOLUTION</th>
<th> DATE</th>

<th> EDIT</th>
<th> REMUVED</th>
</tr>
<?php
$s_id=$_SESSION['s_id'];
$sel_stu="select * from s_exp_q where s_id='$s_id' ";
$stu=mysqli_query($con,$sel_stu);

$num=mysqli_num_rows($stu);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($stu);
		$co_id=$row['ques_id'];	
	$co_name=$row['co_name'];
	$date=$row['date'];
	$ans=$row['ans'];
	$co_image=$row['co_image'];
	$subject=$row['subject'];
	$question=$row['question'];
?>


<tr style="color:#FFF; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><a href="# "  style="text-decoration:none;" > <img src='../co_image/<?php echo $co_image; ?>' 
					'height='25%' 	width='35%' /></a> </td>
<td><?php echo $co_name;?></td>
<td><?php echo $subject;?></td>
<td><?php echo $question;?></td>


<td><?php echo $ans;?></td>
<td><?php echo $date;?></td>

<td> <a href=" edit_post.php?edit=<?php   echo $co_id;?> "  style="text-decoration:none; color:green;" > EDIT </a></td>
<td> <a href=" s_account.php?delete_q=<?php   echo $co_id;?>"  style="text-decoration:none; color:red; " >  DELETE </a></td>
</tr>
	
<?php }
?>

</table>
</form>
</body>
</html>

<?php  ?>