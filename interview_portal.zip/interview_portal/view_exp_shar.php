<?php 
@session_start();

include('include/db.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Interview Experience Sharing Portal!</title>

<style type="text/css">

</style>
</head>



<body >
<div style="position:absolute;">
<div>
		<center>
		<form method="get" action="search_question.php" enctype="meltipart/form-data"  >
		<table style="height:auto; width:80%; background-color:#CCC;">
		<tr>
		<th >
				
		<input type="text" name="search_question"  placeholder=" Search Company Name" style="width:50%; height:40px;		font-size:28px;		text-align:left; margin:0px;padding:0px;" required/>
		
<button  name="search" ><img src="image/searching.jfif" height="40px" width="40px"   /></button>
		

	</th>
		</tr>
		</table>
		</form>
       
        </center>
		</div>

<form method="post" action="">
<table align="center" style="background-color:#FFF; color:#0F0; border:solid; ;" height="auto"width="100%">
<tr>    </tr>
<tr> <h2 colspan='8' align="center" style='color:#FF0000; font-style:italic; font-size:36px;wordspace:30px; background-color:#CCC;'> Views All  Interview Experience Sharing Company</h2></tr>
<tr> 
<th>COM No</th>
<th> IMAGE</th>
<th> NAME</th>
<th> SUBJECT</th>

<th> QUESTION</th>
<th style="width:40%;"> SOLUTION</th>

</tr>
<?php

$sel_stu="select * from s_exp_q";
$run_pro=mysqli_query($con,$sel_stu);
$num=mysqli_num_rows($run_pro);

for($i=1;$i<=$num;$i++){
	
	$row=mysqli_fetch_array($run_pro);
	$s_id=$row['s_id'];
	$co_name=$row['co_name'];
	$subject=$row['subject'];
	$question=$row['question'];
	$image=$row['co_image'];
	$solution=$row['ans'];
	$ques_id=$row['ques_id'];
?>


<tr style="color:#999; text-align:center"> 
<td style="color:black;"> <?php echo $i;?></td>
<td><a href="single_com.php?single_q=<?php echo $ques_id;?>"  style="text-decoration:none;" > <img src='co_image/<?php echo $image; ?>' 
					'height='25%' 	width='35%' /></a> </td>
<td > <span > <?php echo $co_name;?></span> </td>
<td><?php echo $subject;?></td>
<td><?php echo $question;?></td>

<td><?php echo $solution;?></td>

</tr>
	
<?php }
?>

</table>
</form>
</div>
</body>
</html>

<?php  ?>